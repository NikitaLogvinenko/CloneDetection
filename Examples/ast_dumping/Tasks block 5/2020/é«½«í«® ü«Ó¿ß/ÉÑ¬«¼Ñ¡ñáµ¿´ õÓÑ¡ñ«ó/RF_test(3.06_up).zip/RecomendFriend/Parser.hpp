#ifndef Parser_hpp
#define Parser_hpp

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include "UserAction.hpp"

ContainerUsers parser (std::istream &stream);
#endif /* Parser_hpp */
