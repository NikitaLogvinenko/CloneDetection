#include "Parser.hpp"
#include <sstream>
#include <cstdlib>
#include <gtest/gtest.h>

TEST (Parser, valid){
    
    std::set<int> test_set;
    std::stringstream stream;
    stream << "user_1_id user_20_id" << '\n' << "user_20_id user_303_id" << '\n' << "user_303_id user_4196_id";
    
    ContainerUsers users = parser(stream);
    
    
    ASSERT_TRUE(users.findUser(1) != nullptr);
    ASSERT_TRUE(users.findUser(20) != nullptr);
    ASSERT_TRUE(users.findUser(303) != nullptr);
    ASSERT_TRUE(users.findUser(4196) != nullptr);
    test_set = {20};
    ASSERT_TRUE(users.findUser(1)->getFriendsId() == test_set);
    test_set = {1, 303};
    ASSERT_TRUE(users.findUser(20)->getFriendsId() == test_set);
    test_set = {20, 4196};
    ASSERT_TRUE(users.findUser(303)->getFriendsId() == test_set);
    test_set = {303};
    ASSERT_TRUE(users.findUser(4196)->getFriendsId() == test_set);
}


TEST (Parser, invalid){
    
    std::set<int> test_set;
    std::stringstream stream;
    stream << "useer_1_id user_20_id" << '\n' << "user_20_id users_303_id" << '\n' << "user_303_i d user_4196_id" << '\n' << "user_100_id user_200_id";
    
    ContainerUsers users = parser(stream);
    
    ASSERT_TRUE(users.findUser(100) != nullptr);
    ASSERT_TRUE(users.findUser(200) != nullptr);
    test_set = {200};
    ASSERT_TRUE(users.findUser(100)->getFriendsId() == test_set);
    test_set = {100};
    ASSERT_TRUE(users.findUser(200)->getFriendsId() == test_set);
}

TEST (RecommendFriend, koef){
    
    std::set<int> test_set;
    std::vector<int> test_vector;
    std::stringstream stream;
    stream << "user_1_id user_2_id" << '\n'
    << "user_1_id user_3_id" << '\n'
    << "user_1_id user_4_id" << '\n'
    << "user_1_id user_5_id" << '\n'
    << "user_1_id user_6_id" << '\n'
    << "user_1_id user_7_id" << '\n'
    << "user_1_id user_8_id" << '\n'
    << "user_1_id user_9_id" << '\n'
    << "user_1_id user_10_id" << '\n'
    << "user_1_id user_11_id" << '\n'
    
    << "user_2_id user_20_id" << '\n'
    << "user_2_id user_21_id" << '\n'
    << "user_2_id user_22_id" << '\n'
    << "user_2_id user_23_id" << '\n'
    << "user_2_id user_24_id" << '\n'
    << "user_2_id user_25_id" << '\n'
    << "user_2_id user_26_id" << '\n'
    << "user_2_id user_27_id" << '\n'
    << "user_2_id user_28_id" << '\n'
    << "user_2_id user_29_id" << '\n'
    
    << "user_20_id user_3_id" << '\n'
    << "user_20_id user_4_id" << '\n'
    << "user_20_id user_5_id" << '\n'
    << "user_20_id user_6_id" << '\n'
    << "user_20_id user_7_id" << '\n'
    << "user_20_id user_8_id" << '\n'
    << "user_20_id user_9_id" << '\n'
    << "user_20_id user_10_id" << '\n'
    << "user_20_id user_11_id" << '\n'
    
    << "user_21_id user_3_id" << '\n'
    << "user_21_id user_4_id" << '\n'
    << "user_21_id user_5_id" << '\n'
    << "user_21_id user_6_id" << '\n'
    << "user_21_id user_7_id" << '\n'
    << "user_21_id user_8_id" << '\n'
    << "user_21_id user_9_id" << '\n'
    << "user_21_id user_10_id" << '\n'
    
    << "user_22_id user_3_id" << '\n'
    << "user_22_id user_4_id" << '\n'
    << "user_22_id user_5_id" << '\n'
    << "user_22_id user_6_id" << '\n'
    << "user_22_id user_7_id" << '\n'
    << "user_22_id user_8_id" << '\n'
    << "user_22_id user_9_id" << '\n'
    
    << "user_23_id user_3_id" << '\n'
    << "user_23_id user_4_id" << '\n'
    << "user_23_id user_5_id" << '\n'
    << "user_23_id user_6_id" << '\n'
    << "user_23_id user_7_id" << '\n'
    << "user_23_id user_8_id" << '\n'
    
    << "user_24_id user_3_id" << '\n'
    << "user_24_id user_4_id" << '\n'
    << "user_24_id user_5_id" << '\n'
    << "user_24_id user_6_id" << '\n'
    << "user_24_id user_7_id" << '\n'
    
    << "user_25_id user_3_id" << '\n'
    << "user_25_id user_4_id" << '\n'
    << "user_25_id user_5_id" << '\n'
    << "user_25_id user_6_id" << '\n'
    
    << "user_26_id user_3_id" << '\n'
    << "user_26_id user_4_id" << '\n'
    << "user_26_id user_5_id" << '\n'
    
    << "user_27_id user_3_id" << '\n'
    << "user_27_id user_4_id" << '\n'
    
    << "user_28_id user_3_id" << '\n';
    
    ContainerUsers users = parser(stream);
    
    test_set = recommendFriend(users, 1, 100);
    std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
    ASSERT_TRUE(test_vector.size() == 1);
    ASSERT_TRUE(test_vector[0] == 20);
    
    for (int i = 90; i < 100; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 2);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
    }
    
    for (int i = 80; i < 90; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 3);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
    }
        
    for (int i = 70; i < 80; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 4);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
    }
        
    for (int i = 60; i < 70; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 5);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
    }
     
    for (int i = 50; i < 60; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 6);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
        ASSERT_TRUE(test_vector[5] == 25);
    }
    
    for (int i = 40; i < 50; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 7);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
        ASSERT_TRUE(test_vector[5] == 25);
        ASSERT_TRUE(test_vector[6] == 26);
    }
        
    for (int i = 30; i < 40; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 8);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
        ASSERT_TRUE(test_vector[5] == 25);
        ASSERT_TRUE(test_vector[6] == 26);
        ASSERT_TRUE(test_vector[7] == 27);
    }
        
    for (int i = 20; i < 30; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 9);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
        ASSERT_TRUE(test_vector[5] == 25);
        ASSERT_TRUE(test_vector[6] == 26);
        ASSERT_TRUE(test_vector[7] == 27);
        ASSERT_TRUE(test_vector[8] == 28);
    }
    
    for (int i = 0; i < 20; ++i){
        test_set = recommendFriend(users, 1, i);
        test_vector.clear();
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == 10);
        ASSERT_TRUE(test_vector[0] == 20);
        ASSERT_TRUE(test_vector[1] == 21);
        ASSERT_TRUE(test_vector[2] == 22);
        ASSERT_TRUE(test_vector[3] == 23);
        ASSERT_TRUE(test_vector[4] == 24);
        ASSERT_TRUE(test_vector[5] == 25);
        ASSERT_TRUE(test_vector[6] == 26);
        ASSERT_TRUE(test_vector[7] == 27);
        ASSERT_TRUE(test_vector[8] == 28);
        ASSERT_TRUE(test_vector[9] == 29);
    }
}


TEST (RecommendFriend, user_id){
    
    std::set<int> test_set;
    std::vector<int> test_vector;
    std::stringstream stream;
    stream << "user_1_id user_2_id" << '\n'
    << "user_1_id user_3_id" << '\n'
    << "user_1_id user_4_id" << '\n'
    << "user_1_id user_5_id" << '\n'
    << "user_1_id user_6_id" << '\n'
    << "user_1_id user_7_id" << '\n'
    << "user_1_id user_8_id" << '\n'
    << "user_1_id user_9_id" << '\n'
    << "user_1_id user_10_id" << '\n'
    << "user_1_id user_11_id" << '\n'
    
    << "user_2_id user_3_id" << '\n'
    << "user_2_id user_4_id" << '\n'
    << "user_2_id user_5_id" << '\n'
    << "user_2_id user_6_id" << '\n'
    << "user_2_id user_7_id" << '\n'
    << "user_2_id user_8_id" << '\n'
    << "user_2_id user_9_id" << '\n'
    << "user_2_id user_10_id" << '\n'
    << "user_2_id user_11_id" << '\n'
    << "user_2_id user_20_id" << '\n'
    << "user_2_id user_21_id" << '\n'
    << "user_2_id user_22_id" << '\n'
    << "user_2_id user_23_id" << '\n'
    << "user_2_id user_24_id" << '\n'
    << "user_2_id user_25_id" << '\n'
    << "user_2_id user_26_id" << '\n'
    << "user_2_id user_27_id" << '\n'
    << "user_2_id user_28_id" << '\n'
    << "user_2_id user_29_id" << '\n'
    
    << "user_20_id user_3_id" << '\n'
    << "user_20_id user_4_id" << '\n'
    << "user_20_id user_5_id" << '\n'
    << "user_20_id user_6_id" << '\n'
    << "user_20_id user_7_id" << '\n'
    << "user_20_id user_8_id" << '\n'
    << "user_20_id user_9_id" << '\n'
    << "user_20_id user_10_id" << '\n'
    << "user_20_id user_11_id" << '\n'
    
    << "user_21_id user_4_id" << '\n'
    << "user_21_id user_5_id" << '\n'
    << "user_21_id user_6_id" << '\n'
    << "user_21_id user_7_id" << '\n'
    << "user_21_id user_8_id" << '\n'
    << "user_21_id user_9_id" << '\n'
    << "user_21_id user_10_id" << '\n'
    << "user_21_id user_11_id" << '\n'
    
    << "user_22_id user_5_id" << '\n'
    << "user_22_id user_6_id" << '\n'
    << "user_22_id user_7_id" << '\n'
    << "user_22_id user_8_id" << '\n'
    << "user_22_id user_9_id" << '\n'
    << "user_22_id user_10_id" << '\n'
    << "user_22_id user_11_id" << '\n'
    
    << "user_23_id user_6_id" << '\n'
    << "user_23_id user_7_id" << '\n'
    << "user_23_id user_8_id" << '\n'
    << "user_23_id user_9_id" << '\n'
    << "user_23_id user_10_id" << '\n'
    << "user_23_id user_11_id" << '\n'
    
    << "user_24_id user_7_id" << '\n'
    << "user_24_id user_8_id" << '\n'
    << "user_24_id user_9_id" << '\n'
    << "user_24_id user_10_id" << '\n'
    << "user_24_id user_11_id" << '\n'
    
    << "user_25_id user_8_id" << '\n'
    << "user_25_id user_9_id" << '\n'
    << "user_25_id user_10_id" << '\n'
    << "user_25_id user_11_id" << '\n'
    
    << "user_26_id user_9_id" << '\n'
    << "user_26_id user_10_id" << '\n'
    << "user_26_id user_11_id" << '\n'
    
    << "user_27_id user_10_id" << '\n'
    << "user_27_id user_11_id" << '\n'
    
    << "user_28_id user_11_id" << '\n';
    
    ContainerUsers users = parser(stream);
    
    for(int i = 20; i <= 29; ++i){
        test_set = recommendFriend(users, i, 0);
        std::copy(test_set.begin(), test_set.end(), std::inserter(test_vector, test_vector.end()));
        ASSERT_TRUE(test_vector.size() == i - 10);
        ASSERT_TRUE(test_vector[0] == 1);
        if(i >= 21) ASSERT_TRUE(test_vector[1] == 3);
        if(i >= 22) ASSERT_TRUE(test_vector[2] == 4);
        if(i >= 23) ASSERT_TRUE(test_vector[3] == 5);
        if(i >= 24) ASSERT_TRUE(test_vector[4] == 6);
        if(i >= 25) ASSERT_TRUE(test_vector[5] == 7);
        if(i >= 26) ASSERT_TRUE(test_vector[6] == 8);
        if(i >= 27) ASSERT_TRUE(test_vector[7] == 9);
        if(i >= 28) ASSERT_TRUE(test_vector[8] == 10);
        if(i >= 29) ASSERT_TRUE(test_vector[9] == 11);
        

        if(i >= 21)  ASSERT_TRUE(test_vector[i-19] == 20); else ASSERT_TRUE(test_vector[i-19] == 21);
        if(i >= 22)  ASSERT_TRUE(test_vector[i-18] == 21); else ASSERT_TRUE(test_vector[i-18] == 22);
        if(i >= 23)  ASSERT_TRUE(test_vector[i-17] == 22); else ASSERT_TRUE(test_vector[i-17] == 23);
        if(i >= 24)  ASSERT_TRUE(test_vector[i-16] == 23); else ASSERT_TRUE(test_vector[i-16] == 24);
        if(i >= 25)  ASSERT_TRUE(test_vector[i-15] == 24); else ASSERT_TRUE(test_vector[i-15] == 25);
        if(i >= 26)  ASSERT_TRUE(test_vector[i-14] == 25); else ASSERT_TRUE(test_vector[i-14] == 26);
        if(i >= 27)  ASSERT_TRUE(test_vector[i-13] == 26); else ASSERT_TRUE(test_vector[i-13] == 27);
        if(i >= 28)  ASSERT_TRUE(test_vector[i-12] == 27); else ASSERT_TRUE(test_vector[i-12] == 28);
        if(i >= 29)  ASSERT_TRUE(test_vector[i-11] == 28); else ASSERT_TRUE(test_vector[i-11] == 29);
        
        test_vector.clear();
    }
}
