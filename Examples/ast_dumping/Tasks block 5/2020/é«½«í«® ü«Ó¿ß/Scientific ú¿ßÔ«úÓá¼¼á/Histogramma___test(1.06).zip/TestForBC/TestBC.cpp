#include <gtest/gtest.h>
#include "Bar_chart.hpp"
#include "Exceptions.hpp"

TEST (CreateBC, vector){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};

    std::vector <size_t> bar = first.getBarChart();
    ASSERT_TRUE(bar.size() == 4);
    ASSERT_TRUE(bar[0] == 2);
    ASSERT_TRUE(bar[1] == 2);
    ASSERT_TRUE(bar[2] == 1);
    ASSERT_TRUE(bar[3] == 3);

}

TEST (CreateBC, stream){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};
    std::stringstream stream;
    stream << "-10 1 3 4 5 8 24 29";

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, stream};

    std::vector <size_t> bar = first.getBarChart();
    ASSERT_TRUE(bar.size() == 4);
    ASSERT_TRUE(bar[0] == 2);
    ASSERT_TRUE(bar[1] == 2);
    ASSERT_TRUE(bar[2] == 1);
    ASSERT_TRUE(bar[3] == 3);

}

TEST (BCInstruments, insertElem){

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count};
    first.insertElem(-5);
    first.insertElem(2);
    first.insertElem(3.5);
    first.insertElem(10);
    first.insertElem(200);

    std::vector <size_t> bar = first.getBarChart();
    ASSERT_TRUE(bar.size() == 4);
    ASSERT_TRUE(bar[0] == 2);
    ASSERT_TRUE(bar[1] == 1);
    ASSERT_TRUE(bar[2] == 0);
    ASSERT_TRUE(bar[3] == 2);
    
    first.insertElem(4.1);
    bar = first.getBarChart();
    ASSERT_TRUE(bar.size() == 4);
    ASSERT_TRUE(bar[0] == 2);
    ASSERT_TRUE(bar[1] == 2);
    ASSERT_TRUE(bar[2] == 0);
    ASSERT_TRUE(bar[3] == 2);
    
}


TEST (BCInstruments, getMaxMinBinCount){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};

    
    ASSERT_TRUE(first.getMin() == 0);
    ASSERT_TRUE(first.getMax() == 10);
    ASSERT_TRUE(first.getBinCount() == 4);
    
}


TEST (BCOperator, plus){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};
    std::vector <float> vec2 = {1, 3, 6, 8};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};
    BarChart second{min, max, bin_count, vec2};
    BarChart third{min, max, bin_count};
    BarChart forth{min, 9, bin_count, vec};
    
    std::vector <size_t> bar_1 = first.getBarChart();
    ASSERT_TRUE(bar_1.size() == 4);
    ASSERT_TRUE(bar_1[0] == 2);
    ASSERT_TRUE(bar_1[1] == 2);
    ASSERT_TRUE(bar_1[2] == 1);
    ASSERT_TRUE(bar_1[3] == 3);
    
    std::vector <size_t> bar_2 = second.getBarChart();
    ASSERT_TRUE(bar_2.size() == 4);
    ASSERT_TRUE(bar_2[0] == 1);
    ASSERT_TRUE(bar_2[1] == 1);
    ASSERT_TRUE(bar_2[2] == 1);
    ASSERT_TRUE(bar_2[3] == 1);

    third = first + second;
    
    std::vector <size_t> bar_3 = third.getBarChart();
    ASSERT_TRUE(bar_3.size() == 4);
    ASSERT_TRUE(bar_3[0] == 3);
    ASSERT_TRUE(bar_3[1] == 3);
    ASSERT_TRUE(bar_3[2] == 2);
    ASSERT_TRUE(bar_3[3] == 4);

    try {
        third = forth + first;
    } catch (std::exception& ex) {
        ASSERT_TRUE(ex.what() == "Main parameters not equal");
    }
    bar_3 = third.getBarChart();
    ASSERT_TRUE(bar_3.size() == 4);
    ASSERT_TRUE(bar_3[0] == 3);
    ASSERT_TRUE(bar_3[1] == 3);
    ASSERT_TRUE(bar_3[2] == 2);
    ASSERT_TRUE(bar_3[3] == 4);
}


TEST (BCOperator, minus){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};
    std::vector <float> vec2 = {1, 3, 6, 8};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};
    BarChart second{min, max, bin_count, vec2};
    BarChart third{min, max, bin_count};
    BarChart forth{2, max, bin_count, vec};
    
    std::vector <size_t> bar_1 = first.getBarChart();
    ASSERT_TRUE(bar_1.size() == 4);
    ASSERT_TRUE(bar_1[0] == 2);
    ASSERT_TRUE(bar_1[1] == 2);
    ASSERT_TRUE(bar_1[2] == 1);
    ASSERT_TRUE(bar_1[3] == 3);
    
    std::vector <size_t> bar_2 = second.getBarChart();
    ASSERT_TRUE(bar_2.size() == 4);
    ASSERT_TRUE(bar_2[0] == 1);
    ASSERT_TRUE(bar_2[1] == 1);
    ASSERT_TRUE(bar_2[2] == 1);
    ASSERT_TRUE(bar_2[3] == 1);
    
    third = first - second;
    
    std::vector <size_t> bar_3 = third.getBarChart();
    ASSERT_TRUE(bar_3.size() == 4);
    ASSERT_TRUE(bar_3[0] == 1);
    ASSERT_TRUE(bar_3[1] == 1);
    ASSERT_TRUE(bar_3[2] == 0);
    ASSERT_TRUE(bar_3[3] == 2);

    try {
        third = forth - first;
    } catch (std::exception& ex) {
        ASSERT_TRUE(ex.what() == "Main parameters not equal");
    }
    bar_3 = third.getBarChart();
    ASSERT_TRUE(bar_3.size() == 4);
    ASSERT_TRUE(bar_3[0] == 1);
    ASSERT_TRUE(bar_3[1] == 1);
    ASSERT_TRUE(bar_3[2] == 0);
    ASSERT_TRUE(bar_3[3] == 2);
}


TEST (BCOperator, equal){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};
    std::vector <float> vec2 = {1, 1, 3, 4.5, 6, 9, 8, 100};
    std::vector <float> vec3 = {1, 3, 6, 8};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};
    BarChart second{min, max, bin_count, vec2};
    BarChart third{min, max, bin_count, vec3};
    BarChart forth{min, max, 5, vec};
    
    ASSERT_TRUE(first == second);
    ASSERT_FALSE(first == third);
    

    try {
        third == forth;
    } catch (std::exception& ex) {
        ASSERT_TRUE(ex.what() == "Main parameters not equal");
    }
}



TEST (BCInstruments, iterator){
    std::vector <float> vec = {-10,1,3,4,5,8,24,29};

    float min = 0;
    float max = 10;
    size_t bin_count = 4;

    BarChart first{min, max, bin_count, vec};

    std::vector <size_t> bar;
    std::copy(first.begin(), first.end(), std::inserter(bar, bar.end()));
    ASSERT_TRUE(bar.size() == 4);
    ASSERT_TRUE(bar[0] == 2);
    ASSERT_TRUE(bar[1] == 2);
    ASSERT_TRUE(bar[2] == 1);
    ASSERT_TRUE(bar[3] == 3);
    
}
