#include <gtest/gtest.h>

int main(int argc, const char * argv[]) {
    
    testing::InitGoogleTest();
    return RUN_ALL_TESTS();
}
