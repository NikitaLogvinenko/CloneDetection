#include "pch.h"
#include "..\ScientificHistogram\ScientificHistogram.hpp"

TEST(Scientific_Histogram, ConstructorValid) {
	{
		double min = 0;
		double max = 10;
		size_t bin = 12;
		double step = (max - min) / (double)bin;

		ScientificHistogram bar = ScientificHistogram(min, max, bin);

		ASSERT_EQ(bar.GetBin(), bin);
		ASSERT_EQ(bar.GetMax(), max);
		ASSERT_EQ(bar.GetMin(), min);
		ASSERT_EQ(bar.GetStep(), step);
	}

	{
		double min = 23.134;
		double max = 56.234;
		size_t bin = 30;
		double step = (max - min) / (double)bin;

		ScientificHistogram bar = ScientificHistogram(min, max, bin);

		ASSERT_EQ(bar.GetBin(), bin);
		ASSERT_EQ(bar.GetMax(), max);
		ASSERT_EQ(bar.GetMin(), min);
		ASSERT_EQ(bar.GetStep(), step);
	}

}
TEST(Scientific_Histogram, ConstructorNoValid) {
	{
		double min = 0;
		double max = 10;
		size_t bin = 12;
		double step = (max - min) / (double)bin;

		EXPECT_THROW(ScientificHistogram bar(max, max, bin) ,Incorrect_Arguments);
	}

	{
		double min = 23.134;
		double max = 56.234;
		size_t bin = 30;
		double step = (max - min) / (double)bin;

		EXPECT_THROW(ScientificHistogram bar(max, max, bin), Incorrect_Arguments);
	}

}

TEST(Create,FromString){
	std::istringstream str("1 2 3 10");
	ScientificHistogram bar(1, 10, 9);
	bar.Create(str);
	std::string result = "1 1 1 0 0 0 0 0 1 \n";
	std::ostringstream os;
	bar.Print(os);
	EXPECT_EQ(os.str(), result);
	}

TEST(Create, FromVector){
		std::vector<double> vector = { 1,2,3 };
		ScientificHistogram bar(1, 4, 3);
		bar.Create(vector);
		std::vector<int> test = { 1,1,1 };
		ASSERT_TRUE(bar.vector() == test);
	}
TEST(Create, Double) {
	{
		std::vector<double> vector = { 1.2 , 1.9 ,2 , 2.7 ,3.8 , 4 , 4.5 };
		ScientificHistogram bar(1, 5, 4);
		bar.Create(vector);
		std::vector<int> test = { 2,2,1,2 };
		ASSERT_TRUE(bar.vector() == test);
	}
	{
		std::istringstream str("1.2  1.9  2  2.7 3.8  4  4.5");
		ScientificHistogram bar(1, 5, 4);
		bar.Create(str);
		std::string result = "2 2 1 2 \n";
		std::ostringstream os;
		bar.Print(os);
		EXPECT_EQ(os.str(), result);
	}
}
TEST(Create, Range) {
		std::vector<double> vector = { 0.8 , 5 , 0 , 10 , -1 , 8 };
		ScientificHistogram bar(1, 5, 4);
		bar.Create(vector);
		std::vector<int> test = { 3,0,0,3 };
		ASSERT_TRUE(bar.vector() == test);
	}


TEST(OperatorPlusAssigment, Valid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 4, 3);
	bar.Create(vector);
	std::vector<int> test = { 1,2,2 };

	ScientificHistogram bar2(1, 4, 3);
	vector.erase(vector.begin());
	bar2.Create(vector);

	bar2 += bar;

	ASSERT_TRUE(bar2.vector() == test);

}
TEST(OperatorPlusAssigment, NoValid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 5, 3);
	bar.Create(vector);
	std::vector<int> test = { 1,1,1 };

	ScientificHistogram bar2(2, 5, 3);
	bar2.Create(vector);

	EXPECT_THROW(bar2 += bar, Different_State);
}

TEST(OperatorMinusAssigment, Valid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 4, 3);
	bar.Create(vector);
	std::vector<int> test = { 0,0,1 };
	ScientificHistogram bar2(1, 4, 3);
	vector.erase(vector.begin());
	vector[0] ++;
	bar2.Create(vector);
	bar2 -= bar;
	ASSERT_TRUE(bar2.vector() == test);
}
TEST(OperatorMinusAssigment, NoValid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 5, 3);
	bar.Create(vector);
	std::vector<int> test = { 0,0,1 };

	ScientificHistogram bar2(1, 4, 3);
	vector.erase(vector.begin());
	vector[0] ++;
	bar2.Create(vector);

	EXPECT_THROW(bar2 -= bar, Different_State);
	
}

TEST(Compare, Valid) {
	//std::vector<double> vector1 = { 1,2,3,4,5,6,7,8,9 };// 1 1 1 1 1 1 1 1 1 1
	std::istringstream str("1 2 3 4 5 6 7 8 9");
	std::vector<double> vector2 = { 1.2 ,3,4,5.9,7,8 };//  1 0 1 1 1 0 1 1 0
	std::vector<double> vector3 = { 2.2 ,6 , 9.8 };//	   0 1 0 0 0 1 0 0 0

	ScientificHistogram bar1(1, 10, 9);
	bar1.Create(str);
	ScientificHistogram bar2(1, 10, 9);
	bar2.Create(vector2);
	ScientificHistogram bar3(1, 10, 9);
	bar3.Create(vector3);

	ASSERT_TRUE(bar1 != bar3);
	ASSERT_TRUE(!(bar1 == bar3));

	bar3 += bar2;

	ASSERT_TRUE(!(bar1 != bar3));
	ASSERT_TRUE(bar1==bar3);

}
TEST(Compare, NoValid) {
	std::vector<double> vector1 = { 1,2,3,4,5,6,7,8,9 };// 1 1 1 1 1 1 1 1 1 1
	std::vector<double> vector2 = { 1.2 ,3,4,5.9,7,8 };//  1 0 1 1 1 0 1 1 0
	std::vector<double> vector3 = { 2.2 ,6 , 9.8 };//	   0 1 0 0 0 1 0 0 0

	ScientificHistogram bar1(1, 11, 9);
	bar1.Create(vector1);
	ScientificHistogram bar2(1, 10, 9);
	bar2.Create(vector2);
	ScientificHistogram bar3(1, 10, 9);
	bar3.Create(vector3);

	bar3 += bar2;

	EXPECT_THROW(bar3 == bar1, Different_State);
	EXPECT_THROW(bar3 != bar1, Different_State);

}
TEST(OperatorMinus, Valid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 4, 3);
	bar.Create(vector);
	std::vector<int> test = { 0,0,1 };
	ScientificHistogram bar2(1, 4, 3);
	vector.erase(vector.begin());
	vector[0] ++;
	bar2.Create(vector);

	ScientificHistogram bar3(1, 4, 3);

	bar3 = bar2 -bar;
	ASSERT_TRUE(bar3.vector() == test);
}
TEST(OperatorMinus, NoValid) {
	std::vector<double> vector = { 1,2,3 };
	ScientificHistogram bar(1, 5, 3);
	bar.Create(vector);
	std::vector<int> test = { 0,0,1 };

	ScientificHistogram bar2(1, 4, 3);
	vector.erase(vector.begin());
	vector[0] ++;
	bar2.Create(vector);

	ScientificHistogram bar3(1, 4, 3);

	EXPECT_THROW(bar3 = bar2 - bar, Different_State);

}

TEST(OperatorScope, Valid) {
	//std::vector<double> vector = { 2,3 };
	std::istringstream str("2 3");
	ScientificHistogram bar(1, 4, 3);
	bar.Create(str);

	ASSERT_TRUE(bar[0] == 0);
	ASSERT_TRUE(bar[1] == 1);
	ASSERT_TRUE(bar[2] == 1);
}
TEST(OperatorScope, NoValid) {
	//std::vector<double> vector = { 2,3 };
	std::istringstream str("2 3");
	ScientificHistogram bar(1, 4, 3);
	bar.Create(str);

	EXPECT_THROW(bar[3] , Out_of_Range);
	EXPECT_THROW(bar[-1] , Out_of_Range);
}

TEST(Streams, StringInt) {

	std::istringstream str_stream("1 2 3 4 5 6 7 8 9");

	std::string result = "1 1 1 1 1 1 1 1 1 \n";

	ScientificHistogram bar1(1, 10, 9);

	bar1.Create(str_stream);

	std::ostringstream os;

	bar1.Print(os);

	EXPECT_EQ(os.str(), result);

}

TEST(Streams, StringDouble) {

	std::istringstream str_stream("1.2 1.9 2 2.7 3.8  4  4.5");

	std::string result = "2 2 1 2 \n";

	ScientificHistogram bar1(1, 5, 4);

	bar1.Create(str_stream);

	std::ostringstream os;

	bar1.Print(os);

	EXPECT_EQ(os.str(), result);

}

TEST(Iterator, BeginEnd)
{
	{
		std::istringstream str_stream("1 2 3 4 5 6 7 8 9");
		ScientificHistogram bar1(1, 10, 9);
		bar1.Create(str_stream);

		for (auto it = bar1.begin(); it != bar1.end(); it++)
		{
			ASSERT_TRUE(*it == 1);
		}
	}
	{
		std::vector<double> vector = { 1,2,3 };
		ScientificHistogram bar(1, 4, 3);
		bar.Create(vector);

		for (auto it = bar.begin(); it != bar.end(); it++)
		{
			ASSERT_TRUE(*it == 1);
		}
	}
}
TEST(Iterator, Range)
{
	{
		std::vector<double> vector = { 1,2,3 };
		ScientificHistogram bar(1, 4, 3);
		bar.Create(vector);

		for (auto it : bar)
		{
			ASSERT_TRUE(it == 1);
		}
	}

	{
		std::istringstream str_stream("1 2 3 4 5 6 7 8 9");
		ScientificHistogram bar1(1, 10, 9);
		bar1.Create(str_stream);

		for (auto it : bar1)
		{
			ASSERT_TRUE(it == 1);
		}
	}
}
