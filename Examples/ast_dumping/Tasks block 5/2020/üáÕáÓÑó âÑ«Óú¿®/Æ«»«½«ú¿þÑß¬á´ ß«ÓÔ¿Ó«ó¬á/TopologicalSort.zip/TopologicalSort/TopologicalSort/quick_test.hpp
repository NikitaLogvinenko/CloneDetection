#include "Graph.hpp"

void start_test(std::istream&, std::ostream&);