#pragma once
#include <iostream>

void DijkstraForEdgesFromFile(std::istream& in_stream, std::ostream& out_stream);