#pragma once

void sort_graph_from_file(std::istream& in, std::ostream& out);