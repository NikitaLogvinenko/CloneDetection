#ifndef ___PARSE_STRING_H___
#define ___PARSE_STRING_H___


#include <string>
#include <vector>

std::vector<int> parse_string(std::string s);


#endif // ___PARSE_STRING_H___