#include ".//gtest/gtest.h"
#include "../histogram.hpp"

std::vector<std::string> book = {"1", "2", "3", "1", "4", "5", "A", "B", "A", "Histogram", "1"};

TEST(test_constuctors, istream_cons) {
    std::stringstream ss1("1 2 3 4 2 3 1 4 5 1");
    std::stringstream ss2("one two three four two three one four five one");
    Histogram gramm1(ss1);
    Histogram gramm2(ss2);
    std::map<const std::string, int> result1 = {{"1", 3},
                                                {"2", 2},
                                                {"3", 2},
                                                {"4", 2},
                                                {"5", 1}};
    std::map<const std::string, int> method_result1 = get_hist(gramm1);
    EXPECT_TRUE(result1 == method_result1);
    std::map<const std::string, int> result2 = {{"one",   3},
                                                {"two",   2},
                                                {"three", 2},
                                                {"four",  2},
                                                {"five",  1}};
    std::map<const std::string, int> method_result2 = get_hist(gramm2);
    EXPECT_TRUE(result2 == method_result2);
}

TEST(test_constuctors, vector_cons) {
    Histogram gramm(book);
    std::map<const std::string, int> result = {{"1",         3},
                                               {"2",         1},
                                               {"3",         1},
                                               {"4",         1},
                                               {"5",         1},
                                               {"A",         2},
                                               {"B",         1},
                                               {"Histogram", 1}};
    std::map<const std::string, int> method_result = get_hist(gramm);
    EXPECT_TRUE(result == method_result);
}

TEST(operator_test, operator_eq) {
    Histogram gramm1(book);
    Histogram gramm2(book);
    EXPECT_TRUE(gramm1 == gramm2);

}

TEST(test_constuctors, copy_cons) {
    Histogram hist1(book);
    Histogram hist2(hist1);
    EXPECT_TRUE(hist1 == hist2);
}

TEST(operator_test, operator_plus) {
    Histogram hist1(book);
    std::stringstream another_book("1 6 2 5 Another_histogram 4 C 3 1");
    Histogram hist2(another_book);
    Histogram sum = hist1 + hist2;
    std::map<const std::string, int> method_result = get_hist(sum);
    std::map<const std::string, int> result = {{"1",                 5},
                                               {"2",                 2},
                                               {"3",                 2},
                                               {"4",                 2},
                                               {"5",                 2},
                                               {"A",                 2},
                                               {"B",                 1},
                                               {"Histogram",         1},
                                               {"6",                 1},
                                               {"Another_histogram", 1},
                                               {"C",                 1}};
    EXPECT_TRUE(result == method_result);
    hist1 += hist2;
    method_result = get_hist(hist1);
    EXPECT_TRUE(result == method_result);
}

TEST(operator_test, operator_minus) {
    Histogram hist1(book);
    std::stringstream another_book("1 6 2 5 Another_histogram 4 C 3 1");
    Histogram hist2(another_book);
    Histogram dif = hist1 - hist2;
    std::map<const std::string, int> method_result = get_hist(dif);
    std::map<const std::string, int> result = {{"1",                 1},
                                               {"2",                 0},
                                               {"3",                 0},
                                               {"4",                 0},
                                               {"5",                 0},
                                               {"A",                 2},
                                               {"B",                 1},
                                               {"Histogram",         1},
                                               {"C",                 -1},
                                               {"6",                 -1},
                                               {"Another_histogram", -1}};
    EXPECT_TRUE(result == method_result);
    hist1 -= hist2;
    method_result = get_hist(hist1);
    EXPECT_TRUE(result == method_result);
}

TEST(iterator_test, begin_end) {
    Histogram hist(book);
    Histogram empty;
    EXPECT_TRUE(hist.begin() != hist.end());
    std::map<const std::string, int> my_hist = get_hist(hist);
    for (auto &it : hist) {
        const std::pair<const std::string, int> &element = it;
        EXPECT_TRUE(my_hist.find(element.first) != my_hist.end());
    }
    EXPECT_TRUE(empty.begin() == empty.end());
}