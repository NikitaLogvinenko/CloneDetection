#include "pch.h"
#include "..\CheckSum\Crc16.h"

using namespace std;

TEST(CheckSumm, strings) {
	EXPECT_EQ(1, 1);
	EXPECT_TRUE(true);

	string s1 = "Hello, world!";
	stringstream strstream1(s1);
	int summ1 = Crc16::checkSumm(strstream1);
	EXPECT_EQ(29001, summ1);

	string s2 = "My dear friend, How are you?";
	stringstream strstream2(s2);
	int summ2 = Crc16::checkSumm(strstream2);
	EXPECT_EQ(52089, summ2);
}


TEST(CheckSumm, Equal_strings) {
	EXPECT_EQ(1, 1);
	EXPECT_TRUE(true);

	string s1 = "Hello, world!";
	stringstream strstream1(s1);
	int summ1 = Crc16::checkSumm(strstream1);

	string s2 = "Hello, world!";
	stringstream strstream2(s2);
	int summ2 = Crc16::checkSumm(strstream2);

	EXPECT_EQ(summ1, summ2);
}


TEST(CheckSumm, Almost_equal_strings) 
{
  string s2 = "My dear friend, How are you?";
  stringstream strstream2(s2);
  int summ2 = Crc16::checkSumm(strstream2);
  EXPECT_EQ(52089, summ2);

  string s3 = "My dear friend,  How are you?";
  stringstream strstream3(s3);
  int summ3 = Crc16::checkSumm(strstream3);

  EXPECT_TRUE(summ3 != summ2);
}

