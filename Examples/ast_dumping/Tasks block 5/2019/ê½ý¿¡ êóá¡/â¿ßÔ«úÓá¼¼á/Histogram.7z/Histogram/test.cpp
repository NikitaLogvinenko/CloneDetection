#include "pch.h"
#include <iterator>
#include "../Histogram/Histogram.h"

using namespace std;

TEST(Size, size_random) {
	Histogram h1;
	for (int i = 0; i < 100; i++)
		h1.add(rand() / 1000);

	EXPECT_TRUE(h1.size() > 0);
}

TEST(NULL_Histogram, size) {
	Histogram h1;
	EXPECT_TRUE(h1.size() == 0);
}

TEST(NULL_Histogram, summ) {
	Histogram h1;
	Histogram h2;
	Histogram h3 = h1 + h2;
	EXPECT_TRUE(h3.size() == 0);
}

TEST(NULL_Histogram, diff) {
	Histogram h1;
	Histogram h2;
	Histogram h3 = h1 - h2;
	EXPECT_TRUE(h3.size() == 0);
}

TEST(NULL_Histogram, equal) {
	Histogram h1;
	Histogram h2;
	EXPECT_TRUE(h1 == h2);
}

TEST(Operators, summ){
  Histogram h1;
  for (int i = 0; i < 100; i++)
	  h1.add(rand() / 1000);

  Histogram h2 = h1 + h1;

  EXPECT_TRUE(h2.size() > 0);
  for (Histogram::const_iterator it = h2.begin();
	  it != h2.end(); it++)
	  EXPECT_TRUE(it->second == 2*h1.value(it->first));
}


TEST(Operators, diff) {
	Histogram h1;
	for (int i = 0; i < 100; i++)
		h1.add(rand() / 1000);

	Histogram h2 = h1 - h1;

	EXPECT_TRUE(h2.size() > 0);
	for (Histogram::const_iterator it = h2.begin();
		it != h2.end(); it++)
	{
		EXPECT_EQ(it->second, 0);
	}
}

TEST(Operators, equal) {
	Histogram h1;
	for (int i = 0; i < 100; i++)
		h1.add(rand() / 1000);

	Histogram h2 = h1;
	Histogram h3 = h1 + h1;

	EXPECT_TRUE(h2 == h1);
	EXPECT_FALSE(h3 == h1);
}

TEST(Integral, begin_end) {
	map<int, int> histogram = { {1, 2}, {3, 2}, {7, 1} };
	Histogram h1(histogram);

	EXPECT_EQ(histogram.size(), h1.size());

	Histogram::const_iterator it2 = histogram.begin();
	for (Histogram::const_iterator it1 = h1.begin();
		it1 != h1.end(), it2 != histogram.end(); it1++, it2++)
	{
		EXPECT_EQ(it2->first, it1->first);
		EXPECT_EQ(it2->second, it1->second);
	}
}