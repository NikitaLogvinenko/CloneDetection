#include "gtest/gtest.h"
#include "Histogram.h"

TEST(Ctor_test, normal_len) {
	Histogram A(0, 10);
	EXPECT_EQ(A.max(), 10);
	EXPECT_EQ(A.min(), 0);
	EXPECT_EQ(A.bin(), 11);
}

TEST(Ctor_test, one_bin) {
	Histogram A(10, 10);
	EXPECT_EQ(A.max(), 10);
	EXPECT_EQ(A.min(), 10);
	EXPECT_EQ(A.bin(), 1);
}

TEST(Ctor_test, incorrect_max_min) {
	ASSERT_THROW(Histogram A(10, 0), inc_val_ex);
}

TEST(Ctor_test, empty_ctor) {
	Histogram A;
	EXPECT_EQ(A.max(), 0);
	EXPECT_EQ(A.min(), 0);
	EXPECT_EQ(A.bin(), 1);
}

TEST(Ctor_test, look_create_from_vector) {
	std::vector<int> a;
	for (int i = 0; i <= 10; i++) {
		a.push_back(i);
	}
	Histogram B(0, 10, a);
	for (int i = 0; i <= 10; i++) {
		ASSERT_EQ(B[i], 1);
	}
}

TEST(Ctor_test, create_from_stream) {
	std::istringstream file("1 1 2 3 3 4 5 5");
	Histogram B(0, 5, file);
	for (int i = 1; i <= 5; i++) {
		if (i % 2 == 0) ASSERT_EQ(B[i], 1); 
		else ASSERT_EQ(B[i], 2);
	}
}

TEST(Ctor_test, big_len) { //new test
	std::istringstream inp("0 1 2 3 4 5 6");
	Histogram B(2, 4, inp);
	EXPECT_EQ(B[2], 3);
	EXPECT_EQ(B[3], 1);
	EXPECT_EQ(B[4], 3);
}

typedef int data_type;
typedef std::vector<data_type>::const_iterator citer;

TEST(Iter_test, begin_test) {
	std::istringstream inp("0 1 2 3 4 5 6");
	Histogram B(1, 5, inp);
	citer it = B.begin();
	EXPECT_EQ(*it, 2);
}

TEST(Iter_test, end_test) {
	std::istringstream inp("0 1 2 3 4 5 6 7");
	Histogram B(1, 5, inp);
	citer it = --B.end();
	EXPECT_EQ(*it, 3);
}

TEST(Iter_test, iteration_test) {
	std::istringstream inp("0 1 2 3 3 5 6 7");
	Histogram B(1, 5, inp);
	citer it = B.begin();
	EXPECT_EQ(*it, 2);
	it++;
	EXPECT_EQ(*it, 1);
	it++;
	EXPECT_EQ(*it, 2);
}

TEST(Plus_test, correct_test1) {
	std::vector<int> a;
	for (int i = 0; i <= 10; i++) {
		a.push_back(i);
	}
	std::vector<int> b;
	for (int i = 0; i <= 10; i++) {
		b.push_back(1);
	}
	Histogram A(0, 10, a);
	Histogram B(0, 10, a);
	ASSERT_NO_THROW(A + B);
	ASSERT_NO_THROW(A += B); 
	for (int i = 0; i <= 10; i++) {
		ASSERT_EQ(A[i], 2);
	}
}

TEST(Plus_test, correct_test2) {
	std::istringstream inp1("1 1 1 2 2 3 4 4 5 5 5");
	std::istringstream inp2("1 2 2 3 3 3 4 4 5");
	Histogram A(1, 5, inp1);
	Histogram B(1, 5, inp2);
	ASSERT_NO_THROW(A + B);
	ASSERT_NO_THROW(A += B);
	for (int i = 1; i <= 5; i++) {
		ASSERT_EQ(A[i], 4);
	}
}
TEST(Plus_test, correct_test3) {
	std::istringstream inp1("77 75 78 79 76 80");
	std::istringstream inp2("75 78 77 79 80 76");
	Histogram A(75, 80, inp1);
	Histogram B(75, 80, inp2);
	Histogram C; 
	ASSERT_NO_THROW(C = A + B);
	for (int i = 75; i <= 80; i++) {
		ASSERT_EQ(C[i], 2);
	}
}

TEST(Plus_test, different_histograms) {
	Histogram A(0, 5);
	Histogram B(5, 10);
	EXPECT_THROW(A += B, diff_hist_ex);
	EXPECT_THROW(A + B, diff_hist_ex);
}

TEST(Minus_test, correct_test1) {
	std::vector<int> a;
	for (int i = 0; i <= 10; i++) {
		a.push_back(i);
	}
	Histogram A(0, 10, a);
	Histogram B(0, 10, a);
	ASSERT_NO_THROW(A -= B);
	for (int i = 0; i <= 10; i++) {
		ASSERT_EQ(A[i], 0);
	}
}

TEST(Minus_test, correct_test2) {
	std::istringstream inp1("1 1 1 2 2 3 4 4 5 5 5");
	std::istringstream inp2("1 2 2 3 3 3 4 4 5");
	Histogram A(1, 5, inp1);
	Histogram B(1, 5, inp2);
	ASSERT_NO_THROW(A - B);
	ASSERT_NO_THROW(A -= B);
	EXPECT_EQ(A[1], 2);
	EXPECT_EQ(A[2], 0);
	EXPECT_EQ(A[3], -2);
	EXPECT_EQ(A[4], 0);
	EXPECT_EQ(A[5], 2);
}

TEST(Minus_test, correct_test3) {
	std::istringstream inp1("1 1 1 2 2 3 4 4 5 5 5");
	std::istringstream inp2("1 2 2 3 3 3 4 4 5");
	Histogram A(1, 5, inp1);
	Histogram B(1, 5, inp2);
	Histogram C; 
	ASSERT_NO_THROW(C = A - B);
	EXPECT_EQ(C[1], 2);
	EXPECT_EQ(C[2], 0);
	EXPECT_EQ(C[3], -2);
	EXPECT_EQ(C[4], 0);
	EXPECT_EQ(C[5], 2);
}

TEST(Minus_test, different_histograms) {
	Histogram A(0, 5);
	Histogram B(5, 10);
	EXPECT_THROW(A -= B, diff_hist_ex);
	EXPECT_THROW(A - B, diff_hist_ex);
}

TEST(eq_test, correct_test) {
	Histogram A(0, 5);
	Histogram B(0, 5);
	ASSERT_EQ(A == B, 1);
}

TEST(eq_test, different_histograms) {
	Histogram A(0, 5);
	Histogram B(1, 5);
	ASSERT_EQ(A == B, 0);
}

TEST(get_bin_test, elem_in_hist) {
	std::stringstream inp{ "10 11  12 14 14 14 14 15 16 17 18 19 20" };
	Histogram A(10, 20, inp);
	EXPECT_EQ(A[10], 1);
	EXPECT_EQ(A[20], 1);
	EXPECT_EQ(A[14], 4);
}

TEST(get_bin_test, elem_not_in_hist) {
	std::stringstream inp{ "10 11  12 14 14 14 14 15 16 17 18 19 20" };
	Histogram A(10, 20, inp);
	ASSERT_THROW(A[9], no_bin_ex);
	ASSERT_THROW(A[21], no_bin_ex);
	for (int i = 10; i <= 20; i++) {
		ASSERT_NO_THROW(A[i]);
	}

}

TEST(assign_test, correct_test) {
	Histogram A;
	EXPECT_EQ(A[0], 0);
	std::istringstream in("0 1 2 3 4 5 6 7 8 9 10");
	Histogram B(0, 10, in);
	ASSERT_NO_THROW(A = B);
	for (int i = 0; i <= 10; i++) {
		ASSERT_EQ(A[i], B[i]); 
	}
	for (int i = 0; i <= 10; i++) {
		ASSERT_EQ(A[i], 1);
	}
}

TEST(integrate_test, correct_test) {
	std::istringstream file("1 2 2 3 3 3 4 4 4 4 5 5 5 5 5 6 6 6 6 6 6 7 7 7 7 7 7 7");
	Histogram B(0, 5, file);
	EXPECT_EQ(B.integrate(), 28); 
}