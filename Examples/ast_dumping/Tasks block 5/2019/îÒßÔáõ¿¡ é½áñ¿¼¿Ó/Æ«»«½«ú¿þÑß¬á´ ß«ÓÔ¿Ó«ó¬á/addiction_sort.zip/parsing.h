#ifndef ADDICTION_SORT_PARSING_H
#define ADDICTION_SORT_PARSING_H
#include "topological_sort.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
void work_with_file(const std::string &file_in,const std::string &file_out);
#endif //ADDICTION_SORT_PARSING_H
