#include "test.h"
#include <gtest/gtest.h>
#include "../topological_sort.h"

using namespace std;

size_t find(string &str, vector<string> &vec) {
    int count = 0;
    for (const auto &it:vec) {
        if (str == it) break;
        count++;
    }
    if (count == vec.size()) return -1;
    return count;
}

bool correct_sort(string &str, vector<string> &dependence_list, vector<string> &result) {
    size_t str_pos = 0;
    size_t depen_pos = 0;
    str_pos = find(str, result);
    for (auto &it:dependence_list) {
        depen_pos = find(it, result);
        if (depen_pos > str_pos) return false;
    }
    return true;
}

TEST(addiction, addiction_empty_list_Test) {
    string str_1 = {"Вова"};
    vector<string> vec;
    dependence_graph op;
    op.add_knot(str_1, vec);
    vector<string> result = op.topological_sort_by_Tarjan();
    ASSERT_TRUE(result.empty());
}

TEST(addiction, addiction_cycle_Test) {
    string str_1 = {"A"};
    vector<string> vec_1 = {"B", "D", "E"};
    string str_2 = {"B"};
    vector<string> vec_2 = {"C"};
    string str_3 = {"C"};
    vector<string> vec_3 = {"B", "D", "E", "F"};
    dependence_graph op;
    op.add_knot(str_1, vec_1);
    op.add_knot(str_2, vec_2);
    op.add_knot(str_3, vec_3);
    vector<string> result = op.topological_sort_by_Tarjan();
    ASSERT_TRUE(result.empty());
}

TEST(addiction, addiction_sort_primary_Test) {
    string str_1 = {"Вова"};
    vector<string> vec_1 = {"Мама", "Папа", "Саша", "Таня"};
    string str_2 = {"Папа"};
    vector<string> vec_2 = {"Марк", "Сережа", "Саша", "Бабушка"};
    dependence_graph op;
    op.add_knot(str_1, vec_1);
    op.add_knot(str_2, vec_2);
    vector<string> result = op.topological_sort_by_Tarjan();
    ASSERT_TRUE(correct_sort(str_1, vec_1, result));
    ASSERT_TRUE(correct_sort(str_2, vec_2, result));
}

TEST(addiction, addiction_web_Test) {
    string str_1 = {"поехать в магазин"};
    vector<string> vec_1 = {"сесть в машину", "тронуться", "ехать", "остановиться у магазина"};
    string str_2 = {"сесть в машину"};
    vector<string> vec_2 = {"открыть водительскую дверь", "сесть на сиденье", "закрыть дверь", "пристегнуть ремень"};
    string str_3 = {"тронуться"};
    vector<string> vec_3 = {"сесть на сиденье", "завести мотор", "нажать на тормоз", "отпустить ручник",
                            "включить поворотник", "отпустить тормоз", "нажать на газ"};
    string str_4 = {"остановиться у магазина"};
    vector<string> vec_4 = {"ехать", "увидеть магазин", "нажать на тормоз", "остановить автомобиль", "затянуть ручник"};
    dependence_graph op;
    op.add_knot(str_1, vec_1);
    op.add_knot(str_2, vec_2);
    op.add_knot(str_3, vec_3);
    op.add_knot(str_4, vec_4);
    vector<string> result = op.topological_sort_by_Tarjan();
    ASSERT_TRUE(correct_sort(str_1, vec_1, result));
    ASSERT_TRUE(correct_sort(str_2, vec_2, result));
    ASSERT_TRUE(correct_sort(str_3, vec_3, result));
    ASSERT_TRUE(correct_sort(str_4, vec_4, result));
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}