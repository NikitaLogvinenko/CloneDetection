#include <gtest/gtest.h>
#include "../lunch_calculator.h"

using namespace std;

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

TEST(lunch_calculator, lunch_calculator_unvalid_stream_Test) {
    fstream _fstream;
    lunch_calculator calculator(_fstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-16T18:20:00", "2019-05-17T18:20:00");
    ASSERT_TRUE(vec_str.empty());

}
TEST(lunch_calculator, lunch_calculator_stream_with_bad_info_Test) {
    stringstream sstream;
    sstream << "jdfnjnkbfsnjarfsdnbnj";
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-16T18:20:00", "2019-05-17T18:20:00");
    ASSERT_TRUE(vec_str.empty());

}

TEST(lunch_calculator, lunch_calculator_unvalid_time_interval_Test) {
    stringstream sstream;
    sstream << "2019-05-16T18:20:00 Vova 100\n2019-05-16T18:20:00 Sasha -25\n2019-05-16T18:22:00 Misha 200\n2019-05-16T18:22:00 Georgy -150\n2019-05-16T18:30:00 Tanya 300\n2019-05-16T18:30:00 Grey -100";
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-16T18:00:00", "2019-05-10T18:10:00");
    ASSERT_TRUE(vec_str.empty());
    vec_str = calculator.to_offer_advice("2019-05-16T18:40:00", "2019-05-17T18:50:00");
    ASSERT_TRUE(vec_str.empty());
}
TEST(lunch_calculator,lunch_calculator_out_of_time_interval_Test)
{
    stringstream sstream;
    sstream << "2019-05-21T20:01:00 Vova 1000\n"
               "2019-05-21T20:01:00 Arina -100\n"
               "2019-05-21T20:01:00 Sveta -200\n"
               "2019-05-21T20:01:00 Misha -150\n"
               "\n"
               "2019-05-22T20:01:00 Vova -300\n"
               "2019-05-22T20:01:00 Arina -100\n"
               "2019-05-22T20:01:00 Sveta -200\n"
               "2019-05-22T20:01:00 Natasha 700\n"
               "\n"
               "2019-05-23T20:01:00 Arina -100\n"
               "2019-05-23T20:01:00 Sveta 700\n"
               "2019-05-23T20:01:00 Vova -300\n"
               "2019-05-23T20:01:00 Natasha -200";
    vector<string> result = {
            {"Arina -> Sveta - 1 rub. 0 pen.\n"},
            {"Vova -> Sveta - 1 rub. 0 pen.\n"},
            {"Vova -> Natasha - 3 rub. 0 pen.\n"},
            {"Arina -> Natasha - 1 rub. 0 pen.\n"},
            {"Arina -> Vova - 1 rub. 0 pen.\n"},
            {"Misha -> Vova - 1 rub. 50 pen.\n"}};
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-21T20:01:00", "2020-05-23T20:01:00");
    sort(vec_str.begin(),vec_str.end());
    sort(result.begin(),result.end());
    ASSERT_EQ(vec_str, result);
    vec_str = calculator.to_offer_advice("2000-05-21T20:01:00", "2019-05-23T20:01:00");
    sort(vec_str.begin(),vec_str.end());
    sort(result.begin(),result.end());
    ASSERT_EQ(vec_str, result);
}
TEST(lunch_calculator, lunch_calculator_invalid_event_summ_Test) {
    stringstream sstream;
    sstream << "2019-05-16T18:20:00 Vova 1000\n"
               "2019-05-16T18:20:00 Arina -100\n"
               "2019-05-16T18:20:00 Sveta -2000\n"
               "2019-05-16T18:20:00 Misha -150\n"
               "\n"
               "2019-05-17T18:20:00 Vova -300\n"
               "2019-05-17T18:20:00 Arina -1000\n"
               "2019-05-17T18:20:00 Sveta -200\n"
               "2019-05-17T18:20:00 Natasha 700\n";
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-16T18:20:00", "2019-05-17T18:20:00");
    ASSERT_TRUE(vec_str.empty());
}

TEST(lunch_calculator, lunch_calculator_basic_Test) {
    stringstream sstream;
    sstream << "2019-05-21T20:01:00 Vova 1000\n"
               "2019-05-21T20:01:00 Arina -100\n"
               "2019-05-21T20:01:00 Sveta -200\n"
               "2019-05-21T20:01:00 Misha -150\n"
               "\n"
               "2019-05-22T20:01:00 Vova -300\n"
               "2019-05-22T20:01:00 Arina -100\n"
               "2019-05-22T20:01:00 Sveta -200\n"
               "2019-05-22T20:01:00 Natasha 700\n"
               "\n"
               "2019-05-23T20:01:00 Arina -100\n"
               "2019-05-23T20:01:00 Sveta 700\n"
               "2019-05-23T20:01:00 Vova -300\n"
               "2019-05-23T20:01:00 Natasha -200";
    vector<string> result = {
            {"Arina -> Sveta - 1 rub. 0 pen.\n"},
            {"Vova -> Sveta - 1 rub. 0 pen.\n"},
            {"Vova -> Natasha - 3 rub. 0 pen.\n"},
            {"Arina -> Natasha - 1 rub. 0 pen.\n"},
            {"Arina -> Vova - 1 rub. 0 pen.\n"},
            {"Misha -> Vova - 1 rub. 50 pen.\n"}};
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-21T20:01:00", "2019-05-23T20:01:00");
    sort(vec_str.begin(),vec_str.end());
    sort(result.begin(),result.end());
    ASSERT_EQ(vec_str, result);
}

TEST(lunch_calculator, lunch_calculator_hard_Test) {
    stringstream sstream;
    sstream << "2019-05-21T20:01:00 Vova 1000\n"
               "2019-05-21T20:01:00 Arina -100\n"
               "2019-05-21T20:01:00 Sveta -200\n"
               "2019-05-21T20:01:00 Misha -150\n"
               "\n"
               "2019-05-22T20:01:00 Vova -300\n"
               "2019-05-22T20:01:00 Arina -100\n"
               "2019-05-22T20:01:00 Sveta -200\n"
               "2019-05-22T20:01:00 Natasha 700\n"
               "\n"
               "2019-05-23T20:01:00 Arina -100\n"
               "2019-05-23T20:01:00 Sveta 700\n"
               "2019-05-23T20:01:00 Vova -300\n"
               "2019-05-23T20:01:00 Natasha -200\n"
               "\n"
               "2019-05-26T20:01:00 Vova 500\n"
               "2019-05-26T20:01:00 Natasha -300\n"
               "2019-05-26T20:01:00 Vera -100\n"
               "2019-05-26T20:01:00 Arina -50\n"
               "\n"
               "2019-05-28T20:01:00 Sveta 1000\n"
               "2019-05-28T20:01:00 Natasha -500\n"
               "2019-05-28T20:01:00 Vera -250\n"
               "2019-05-28T20:01:00 Vova -100";
    vector<string> result = {
            {"Arina -> Sveta - 1 rub. 0 pen.\n"},
            {"Vova -> Sveta - 2 rub. 0 pen.\n"},
            {"Natasha -> Sveta - 5 rub. 0 pen.\n"},
            {"Vera -> Sveta - 2 rub. 50 pen.\n"},
            {"Arina -> Natasha - 1 rub. 0 pen.\n"},
            {"Arina -> Vova - 1 rub. 50 pen.\n"},
            {"Misha -> Vova - 1 rub. 50 pen.\n"},
            {"Vera -> Vova - 1 rub. 0 pen.\n"}};
    lunch_calculator calculator(sstream);
    vector<string> vec_str;
    vec_str = calculator.to_offer_advice("2019-05-21T20:01:00", "2019-06-28T20:01:00");
    sort(vec_str.begin(),vec_str.end());
    sort(result.begin(),result.end());
    ASSERT_EQ(vec_str, result);
}