#include "gtest/gtest.h"
#include "scientific_histogram.hpp"

#include <fstream>

TEST(MakeSHistTest, IncorrectParam1)
{
	bool bad_constructor = false;
	try
	{
		ScientificHistogram s_hist(3,2, 4);
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
		std::string str = e.what();
		ASSERT_EQ(str, "You got incorrect parameters in your constructor");
	}
	ASSERT_TRUE(bad_constructor);
}

TEST(MakeSHistTest, IncorrectParam2)
{
	bool bad_constructor = false;
	try
	{
		ScientificHistogram s_hist(2, 3, 0);
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
		std::string str = e.what();
		ASSERT_EQ(str, "You got incorrect parameters in your constructor");
	}
	ASSERT_TRUE(bad_constructor);
}

TEST(MakeSHistTest, EmptyVector)
{
	bool bad_constructor = false;
	std::vector<int> input_vec; //empty input vector
	try
	{
		ScientificHistogram s_hist(2, 3, 1,input_vec);
		for (auto it = s_hist.cbegin(); it != s_hist.cend(); it++)
		{
			ASSERT_EQ(it->second, 0);
		}
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
	}
	ASSERT_FALSE(bad_constructor);
}

TEST(MakeSHistTest, NValInputStream)
{
	bool bad_constructor = false;
	try
	{
		std::ifstream stream("NotValStream");
		ScientificHistogram s_hist(2, 3, 1, stream);
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
		std::string str = e.what();
		ASSERT_EQ(str, "Not valid input stream");
	}
	ASSERT_TRUE(bad_constructor);
}

TEST(GetParamTest, GetParamTest)
{
	try {
		ScientificHistogram s_hist(1, 2, 3);
		ASSERT_EQ(s_hist.get_min(), 1);
		ASSERT_EQ(s_hist.get_max(), 2);
		ASSERT_EQ(s_hist.get_bin_count(), 3);
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(CbeginCendTest, CbeginCendTest)
{
	try {
		std::vector<int> input_val = { -2, -3 ,-1, 0, 0,1 };
		ScientificHistogram s_hist(-1, 1, 3,input_val);
		int bin_count = 3;
		for (auto it = s_hist.cbegin(); it != s_hist.cend(); it++) 
		{ 
			ASSERT_EQ(it->second,bin_count); 
			bin_count--;
		}
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(AddElementTest, AddElemTest1)
{
	try {
		ScientificHistogram s_hist(-1, 1, 3);
		ASSERT_EQ(s_hist.cbegin()->second, 0);
		s_hist.add_el(-5);
		ASSERT_EQ(s_hist.cbegin()->second, 1);
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(AddElementTest, AddElemTest2)
{
	try {
		ScientificHistogram s_hist(-1, 1, 3);
		auto it = next(s_hist.cbegin(), s_hist.get_bin_count() - 1);
		ASSERT_EQ(it->second, 0);
		s_hist.add_el(5);
		ASSERT_EQ(it->second, 1);
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(AddElementTest, AddElemTest3)
{
	try {
		ScientificHistogram s_hist(-1, 1, 7);
		auto it = next(s_hist.cbegin(), 2);
		ASSERT_EQ(it->second, 0);
		s_hist.add_el(5);
		ASSERT_EQ(it->second, 1);
		it++;
		while (it != s_hist.cend()) { ASSERT_EQ(it->second, 0); it++; }
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(SummObjectsTest, DifferentParam)
{
	bool bad_constructor = false;
	try
	{
		ScientificHistogram s_hist1(2,3, 4);
		ScientificHistogram s_hist2(3, 3, 4);
		ScientificHistogram summ_s_hist = s_hist1+s_hist2;
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
		std::string str = e.what();
		ASSERT_EQ(str, "Different parameters of scientific histograms");
	}
	ASSERT_TRUE(bad_constructor);
}

TEST(SummObjectsTest, EqualParam)
{
	try
	{
		std::vector<int> vec_val1 = { -10,1000,354,-20,1,1,-1,0}, vec_val2 = { -5,10,32,4,0,1,-3,7 };
		ScientificHistogram s_hist1(-10, 10, 20);
		ScientificHistogram s_hist2(-10, 10, 20);
		ScientificHistogram summ_s_hist = s_hist1 + s_hist2;
		ASSERT_EQ(summ_s_hist.get_min(), s_hist1.get_min());
		ASSERT_EQ(summ_s_hist.get_max(), s_hist1.get_max());
		ASSERT_EQ(summ_s_hist.get_bin_count(), s_hist1.get_bin_count());
		for (auto it1 = s_hist1.cbegin(), it2 = s_hist2.cbegin(), it3 = summ_s_hist.cbegin(); it1 != s_hist1.cend(); it1++, it2++, it3++)
		{
			ASSERT_EQ(it3->second, it1->second + it2->second);
		}
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}

TEST(DifferenceObjectsTest, DifferentParam)
{
	bool bad_constructor = false;
	try
	{
		ScientificHistogram s_hist1(2,3, 4);
		ScientificHistogram s_hist2(3, 3, 4);
		ScientificHistogram summ_s_hist = s_hist1 - s_hist2;
	}
	catch (std::exception & e)
	{
		bad_constructor = true;
		std::string str = e.what();
		ASSERT_EQ(str, "Different parameters of scientific histograms");
	}
	ASSERT_TRUE(bad_constructor);
}

TEST(DifferenceObjectsTest, EqualParam)
{
	try
	{
		std::vector<int> vec_val1 = { -10,1000,354,-20,1,1,-1,0 }, vec_val2 = { -5,10,32,4,0,1,-3,7 };
		ScientificHistogram s_hist1(-10, 10, 20);
		ScientificHistogram s_hist2(-10, 10, 20);
		ScientificHistogram summ_s_hist = s_hist1 - s_hist2;
		ASSERT_EQ(summ_s_hist.get_min(), s_hist1.get_min());
		ASSERT_EQ(summ_s_hist.get_max(), s_hist1.get_max());
		ASSERT_EQ(summ_s_hist.get_bin_count(), s_hist1.get_bin_count());
		for (auto it1 = s_hist1.cbegin(), it2 = s_hist2.cbegin(), it3 = summ_s_hist.cbegin(); it1 != s_hist1.cend(); it1++, it2++, it3++)
		{
			ASSERT_EQ(it3->second, it1->second - it2->second >= 0 ? it1->second - it2->second : 0);
		}
	}
	catch (std::exception & e)
	{
		ASSERT_FALSE(true);
	}
}